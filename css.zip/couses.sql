-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2018 at 09:55 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `couses`
--

-- --------------------------------------------------------

--
-- Table structure for table `down`
--

CREATE TABLE `down` (
  `id` int(11) NOT NULL,
  `usr` varchar(89) NOT NULL,
  `file` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(57) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `down`
--

INSERT INTO `down` (`id`, `usr`, `file`, `date`, `status`) VALUES
(1, 'ola@sample.com', '', '2017-08-10 13:41:29', 'download'),
(2, 'ola@sample.com', '', '2017-08-10 13:48:47', 'download'),
(3, 'dola@g.com', '', '2017-08-28 20:06:31', 'download'),
(4, 'dola@g.com', '', '2017-08-28 20:20:41', 'download'),
(5, 'dola@g.com', 'AGAIN_(Mark_Angel_Comedy)_(Episode_79).mp4', '2017-08-29 02:38:09', 'download');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `tittle` varchar(111) NOT NULL,
  `cod` varchar(29) NOT NULL,
  `level` varchar(23) NOT NULL,
  `type` varchar(35) NOT NULL,
  `note` text NOT NULL,
  `filename` varchar(220) NOT NULL,
  `filepath` varchar(222) NOT NULL,
  `lecturer` varchar(89) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `tittle`, `cod`, `level`, `type`, `note`, `filename`, `filepath`, `lecturer`, `date`, `status`) VALUES
(1, 'my new Tittle', 'csc223', '100', 'doc', 'hoo My God, hoa yeeea hunnn aaaa aaaa! har heaaar ', 'kuyfiu.jpg', '../upload_files/kuyfiu.jpg', 'lasisi lakunle', '2017-12-31 01:15:43', '0');

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE `lecture` (
  `id` int(11) NOT NULL,
  `fn` varchar(111) NOT NULL,
  `ln` varchar(111) NOT NULL,
  `staff_id` varchar(111) NOT NULL,
  `pw` varchar(111) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`id`, `fn`, `ln`, `staff_id`, `pw`, `date`, `status`) VALUES
(1, 'lasisi', 'lakunle', '1234qwer', 'hope', '2017-12-30 14:24:08', '0');

-- --------------------------------------------------------

--
-- Table structure for table `mine`
--

CREATE TABLE `mine` (
  `id` int(11) NOT NULL,
  `email` varchar(39) NOT NULL,
  `num` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mine`
--

INSERT INTO `mine` (`id`, `email`, `num`, `date`, `status`) VALUES
(1, 'ola@sample.com', '4170ac2a2782a1516fe9e13d7322ae482c1bd594', '2017-08-10 11:43:30', '0'),
(2, 'ola@sample.com', '39dfa55283318d31afe5a3ff4a0e3253e2045e43', '2017-08-28 12:31:34', '0'),
(3, 'dola@g.com', '726e69abaf9d464993a90e72970be5485a927aac', '2017-08-28 17:39:06', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `id` int(11) NOT NULL,
  `email` varchar(78) NOT NULL,
  `fname` varchar(111) NOT NULL,
  `lastn` varchar(111) NOT NULL,
  `level` varchar(111) NOT NULL,
  `dapartment` varchar(111) NOT NULL,
  `pass` varchar(78) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`id`, `email`, `fname`, `lastn`, `level`, `dapartment`, `pass`, `date`, `status`) VALUES
(1, 'ola@sample.com', '', '', '', '', 'ola', '2017-07-29 22:31:14', '0'),
(2, 'dola@g.com', '', '', '', '', ' 12345', '2017-08-28 17:38:32', '0'),
(3, '122', 'dddd', 'sss', '100', 'CSC', '5555', '2017-12-24 23:43:26', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `down`
--
ALTER TABLE `down`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lecture`
--
ALTER TABLE `lecture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mine`
--
ALTER TABLE `mine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `down`
--
ALTER TABLE `down`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lecture`
--
ALTER TABLE `lecture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mine`
--
ALTER TABLE `mine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
