<?php session_start()?>
<?php include'../connect.php';?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
     <meta charset="UTF-8">
        <title>Thrift</title>
         <!--<head>-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <a href="index.php"></a>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/css.css" rel="stylesheet">
    <link href="../css/main.css" rel="stylesheet">
    </head>
    <body>
<!--         <div class="logo">
            <img src="../logo3.PNG" class="img-responsive animated bounceInDown"/>
        </div>-->
        <?php
        // put your code here
        include 'hearder.php';
        ?>
<br/>
<br/>
<br/>
        <h1>All Customers</h1>
        <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Customers</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Age</th>
                  <th>Gender</th>
                  <th>Address</th>
                  <th>Occupation</th>
                  <th>Monthly Payment</th>
                  <th>Date</th>
                  
             
                
                </tr>
              </thead>
              <tbody>
                <tr>
                    <?php 
            
                $qy= "select * from reg_customer ";
                   $myqy = mysqli_query($mycon,$qy);
                   $intt = 0;
                   while ($row = mysqli_fetch_array($myqy)) {
                       //echo $row["id"]; 
                       //$intt = $intt+1;
                    
                           
                         $intt = $intt+1;
                   ?>
                    
                    <td><?php echo $intt;?></td>
                  <td><?php echo $row["em"];//video?></td>
                  <td><?php echo $row["fn"];//video?></td>
                  <td><?php echo $row["ln"];//video?></td>
                  <td><?php echo $row["age"];//video?></td>
                  <td><?php echo $row["gender"];//video?></td>
                  <td><?php echo $row["address"];//video?></td>
                  <td><?php echo $row["occupation"];//video?></td>
                  <td><?php echo $row["mp"];//video?></td>
                  <td><?php echo $row["date"];//video?></td>
                
                
                </tr>
                <?php
                       }
//                   }
                ?>


              </tbody>
            </table>
          </div>
        
        
          <script src="../javascript/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../javascript/bootstrap.min.js"></script>
    <script src="../javascript/jquery.1.11.js"></script>
   <script src="../javascript/modal.js"></script>
    </body>
</html>
