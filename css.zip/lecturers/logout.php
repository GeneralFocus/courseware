<?php session_start();?>
<?php session_destroy();?>
<?php echo ' <script type="text/javascript">window.location.replace("index.php") </script>';     ?>
<?php
//  $go = $_SESSION["un"];
//                        $update ="update regs set status='0' where un='$go'";
//                         $mup = mysqli_query($mycon,$update);
//                         if(!$mup){
//                             
//                         } 
//                         else {
//    echo ' <script type="text/javascript">window.location.replace("index.php") </script>';    
//}
?>